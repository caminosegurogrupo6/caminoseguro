
const auth = {
    saveAuth(user) {
        localStorage.setItem('currentUser', JSON.stringify(user));
        localStorage.setItem('isLoggedIn', 'true');
    },

    getUser() {
        const user = localStorage.getItem('currentUser');
        return user ? JSON.parse(user) : null;
    },

    logout() {
        localStorage.removeItem('currentUser');
        localStorage.removeItem('isLoggedIn');
        window.location.href = '../index.html';
    },

    requireAuth() {
        if (!localStorage.getItem('isLoggedIn')) {
            window.location.href = 'login.html';
        }
    },

    redirectIfLoggedIn() {
        if (localStorage.getItem('isLoggedIn')) {
            window.location.href = 'dashboard.html';
        }
    },

    register(userData) {
        // Get existing users
        const users = this.getAllUsers();

        // Check if user already exists
        if (users.find(u => u.email === userData.email)) {
            throw new Error('El usuario ya existe');
        }

        // Add new user
        const newUser = {
            id: Date.now().toString(),
            ...userData,
            createdAt: new Date().toISOString()
        };

        users.push(newUser);
        localStorage.setItem('users', JSON.stringify(users));

        return newUser;
    },

    login(email, password) {
        const users = this.getAllUsers();
        const user = users.find(u => u.email === email && u.password === password);

        if (!user) {
            throw new Error('Credenciales incorrectas');
        }

        // Don't save password in current session
        const { password: _, ...userWithoutPassword } = user;
        this.saveAuth(userWithoutPassword);

        return userWithoutPassword;
    },

    getAllUsers() {
        const users = localStorage.getItem('users');
        return users ? JSON.parse(users) : [];
    }
};

// Local Storage API simulation
const storage = {
    // Reports
    saveReport(report) {
        const reports = this.getAllReports();
        const newReport = {
            uuid: Date.now().toString() + Math.random().toString(36).substr(2, 9),
            ...report,
            createdAt: new Date().toISOString(),
            status: report.status || 'pending'
        };
        reports.push(newReport);
        localStorage.setItem('reports', JSON.stringify(reports));
        return newReport;
    },

    getAllReports() {
        const reports = localStorage.getItem('reports');
        return reports ? JSON.parse(reports) : [];
    },

    getReportById(uuid) {
        const reports = this.getAllReports();
        return reports.find(r => r.uuid === uuid);
    },

    updateReport(uuid, updates) {
        const reports = this.getAllReports();
        const index = reports.findIndex(r => r.uuid === uuid);
        if (index !== -1) {
            reports[index] = { ...reports[index], ...updates, updatedAt: new Date().toISOString() };
            localStorage.setItem('reports', JSON.stringify(reports));
            return reports[index];
        }
        return null;
    },

    deleteReport(uuid) {
        const reports = this.getAllReports();
        const filtered = reports.filter(r => r.uuid !== uuid);
        localStorage.setItem('reports', JSON.stringify(filtered));
        return true;
    },

    getStats() {
        const reports = this.getAllReports();
        const now = new Date();
        const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);

        const recentReports = reports.filter(r => new Date(r.createdAt) > oneDayAgo);
        const resolvedToday = recentReports.filter(r => r.status === 'resolved').length;

        const byType = {};
        reports.forEach(r => {
            byType[r.incidentType] = (byType[r.incidentType] || 0) + 1;
        });

        return {
            reports: {
                total: reports.length,
                last24h: recentReports.length,
                byStatus: {
                    pending: reports.filter(r => r.status === 'pending').length,
                    confirmed: reports.filter(r => r.status === 'confirmed').length,
                    resolved: reports.filter(r => r.status === 'resolved').length,
                    rejected: reports.filter(r => r.status === 'rejected').length
                },
                byType
            },
            zones: {
                highRisk: Math.floor(reports.length / 5),
                mediumRisk: Math.floor(reports.length / 3),
                safe: 42
            },
            users: {
                total: auth.getAllUsers().length
            }
        };
    },

    getHelpPoints() {
        const defaultPoints = [
            {
                id: '1',
                type: 'policia',
                name: 'Comisaría San Isidro',
                lat: -12.0931,
                lng: -77.0465,
                address: 'Av. Arequipa 2245, San Isidro',
                phone: '01-475-2900',
                hours: '24 horas'
            },
            {
                id: '2',
                type: 'serenazgo',
                name: 'Serenazgo Miraflores',
                lat: -12.1196,
                lng: -77.0365,
                address: 'Av. José Larco 1150, Miraflores',
                phone: '01-617-7272',
                hours: '24 horas'
            },
            {
                id: '3',
                type: 'bomberos',
                name: 'Compañía de Bomberos N° 28',
                lat: -12.1211,
                lng: -77.0364,
                address: 'Av. Benavides 400, Miraflores',
                phone: '116',
                hours: '24 horas'
            },
            {
                id: '4',
                type: 'hospital',
                name: 'Clínica Ricardo Palma',
                lat: -12.0897,
                lng: -77.0282,
                address: 'Av. Javier Prado Este 1066, San Isidro',
                phone: '01-224-2224',
                hours: '24 horas'
            },
            {
                id: '5',
                type: 'policia',
                name: 'Comisaría Miraflores',
                lat: -12.1198,
                lng: -77.0289,
                address: 'Av. Reducto 1401, Miraflores',
                phone: '01-445-5786',
                hours: '24 horas'
            },
            {
                id: '6',
                type: 'hospital',
                name: 'Hospital Rebagliati',
                lat: -12.0858,
                lng: -77.0504,
                address: 'Av. Rebagliati 490, Jesús María',
                phone: '01-265-4901',
                hours: '24 horas'
            }
        ];

        const stored = localStorage.getItem('helpPoints');
        return stored ? JSON.parse(stored) : defaultPoints;
    }
};

const api = {
    async get(endpoint) {
        await new Promise(resolve => setTimeout(resolve, 300));

        if (endpoint.startsWith('/stats')) {
            return { success: true, data: storage.getStats() };
        }

        if (endpoint.startsWith('/reports')) {
            const params = new URLSearchParams(endpoint.split('?')[1] || '');
            const status = params.get('status');
            const limit = parseInt(params.get('limit')) || 100;

            let reports = storage.getAllReports();
            if (status) {
                reports = reports.filter(r => r.status === status);
            }

            return {
                success: true,
                data: {
                    reports: reports.slice(0, limit)
                }
            };
        }

        if (endpoint.startsWith('/help-points')) {
            return { success: true, data: storage.getHelpPoints() };
        }

        throw new Error('Endpoint no encontrado');
    },

    async post(endpoint, body) {
        await new Promise(resolve => setTimeout(resolve, 300));

        if (endpoint === '/auth/register') {
            const userData = { ...body, userType: 'user' };
            const user = auth.register(userData);
            return { success: true, data: { user } };
        }

        if (endpoint === '/auth/register-authority') {
            const userData = { ...body, userType: 'authority' };
            const user = auth.register(userData);
            return { success: true, data: { user } };
        }

        if (endpoint === '/auth/login') {
            const user = auth.login(body.email, body.password);
            return { success: true, data: { user } };
        }

        if (endpoint === '/reports') {
            const report = storage.saveReport(body);
            return { success: true, data: { report } };
        }

        throw new Error('Endpoint no encontrado');
    },

    async put(endpoint, body) {
        await new Promise(resolve => setTimeout(resolve, 300));

        const match = endpoint.match(/\/reports\/([^\/]+)\/status/);
        if (match) {
            const uuid = match[1];
            const updated = storage.updateReport(uuid, body);
            return { success: true, data: { report: updated } };
        }

        throw new Error('Endpoint no encontrado');
    },

    async delete(endpoint) {
        await new Promise(resolve => setTimeout(resolve, 300));

        const match = endpoint.match(/\/reports\/([^\/]+)/);
        if (match) {
            const uuid = match[1];
            storage.deleteReport(uuid);
            return { success: true };
        }

        throw new Error('Endpoint no encontrado');
    }
};

const ui = {
    showError(message, container) {
        if (container) {
            container.innerHTML = `
                <div style="background-color: #fee2e2; color: #991b1b; padding: 1rem; border-radius: 0.5rem; margin-bottom: 1rem;">
                    ${message}
                </div>
            `;
        } else {
            alert(message);
        }
    },

    showSuccess(message, container) {
        if (container) {
            container.innerHTML = `
                <div style="background-color: #dcfce7; color: #166534; padding: 1rem; border-radius: 0.5rem; margin-bottom: 1rem;">
                    ${message}
                </div>
            `;
            setTimeout(() => {
                container.innerHTML = '';
            }, 3000);
        }
    },

    showLoading(button, text = 'Cargando...') {
        button.disabled = true;
        button.dataset.originalText = button.innerHTML;
        button.innerHTML = `<span>${text}</span>`;
    },

    hideLoading(button) {
        button.disabled = false;
        if (button.dataset.originalText) {
            button.innerHTML = button.dataset.originalText;
        }
    }
};

// Validation utilities
const validate = {
    email(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    },

    password(password) {
        return password && password.length >= 6;
    },

    required(value) {
        return value && value.trim().length > 0;
    },

    phone(phone) {
        const re = /^[0-9]{9}$/;
        return re.test(phone.replace(/\s/g, ''));
    }
};

function initializeDemoData() {
    if (storage.getAllReports().length === 0) {
        const demoReports = [
            {
                incidentType: 'Robo',
                description: 'Robo de celular en la vía pública',
                location: { address: 'Av. Universitaria 1801, Lima', lat: -12.0464, lng: -77.0428 },
                severity: 'high',
                status: 'confirmed'
            },
            {
                incidentType: 'Asalto',
                description: 'Asalto a mano armada',
                location: { address: 'Parque Kennedy, Miraflores', lat: -12.1196, lng: -77.0365 },
                severity: 'high',
                status: 'confirmed'
            },
            {
                incidentType: 'Accidente',
                description: 'Accidente de tránsito menor',
                location: { address: 'Av. Arequipa 2245, San Isidro', lat: -12.0931, lng: -77.0465 },
                severity: 'medium',
                status: 'resolved'
            }
        ];

        demoReports.forEach(report => storage.saveReport(report));
    }
}

if (typeof window !== 'undefined') {
    window.addEventListener('DOMContentLoaded', () => {
        initializeDemoData();
    });
}
