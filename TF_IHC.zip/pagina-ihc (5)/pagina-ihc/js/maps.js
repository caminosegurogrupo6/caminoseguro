
function initHelpPointsMap(elementId) {
    const mapElement = document.getElementById(elementId);
    if (!mapElement) return null;

    const map = L.map(elementId).setView([-12.0464, -77.0428], 13);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors',
        maxZoom: 19
    }).addTo(map);


    loadHelpPoints(map);

    return map;
}


function loadHelpPoints(map, filter = 'all') {
    map.eachLayer((layer) => {
        if (layer instanceof L.Marker) {
            map.removeLayer(layer);
        }
    });

    const helpPoints = storage ? storage.getHelpPoints() : getDefaultHelpPoints();

    const filteredPoints = filter === 'all'
        ? helpPoints
        : helpPoints.filter(p => p.type === filter);

    filteredPoints.forEach(point => {
        const color = getMarkerColor(point.type);
        const icon = L.divIcon({
            className: 'custom-marker',
            html: `<div style="background-color: ${color}; width: 30px; height: 30px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 5px rgba(0,0,0,0.3);"></div>`,
            iconSize: [30, 30]
        });

        const popupContent = `
            <div style="min-width: 200px;">
                <strong style="font-size: 14px; display: block; margin-bottom: 8px;">${point.name}</strong>
                <p style="margin: 4px 0; font-size: 12px;">${point.address}</p>
                ${point.phone ? `<p style="margin: 4px 0; font-size: 12px;"><strong>Teléfono:</strong> ${point.phone}</p>` : ''}
                ${point.hours ? `<p style="margin: 4px 0; font-size: 12px;"><strong>Horario:</strong> ${point.hours}</p>` : ''}
            </div>
        `;

        L.marker([point.lat, point.lng], { icon })
            .bindPopup(popupContent)
            .addTo(map);
    });
}

function getDefaultHelpPoints() {
    return [
        {
            id: '1',
            type: 'policia',
            name: 'Comisaría San Isidro',
            lat: -12.0931,
            lng: -77.0465,
            address: 'Av. Arequipa 2245, San Isidro',
            phone: '01-475-2900',
            hours: '24 horas'
        },
        {
            id: '2',
            type: 'serenazgo',
            name: 'Serenazgo Miraflores',
            lat: -12.1196,
            lng: -77.0365,
            address: 'Av. José Larco 1150, Miraflores',
            phone: '01-617-7272',
            hours: '24 horas'
        },
        {
            id: '3',
            type: 'bomberos',
            name: 'Compañía de Bomberos N° 28',
            lat: -12.1211,
            lng: -77.0364,
            address: 'Av. Benavides 400, Miraflores',
            phone: '116',
            hours: '24 horas'
        },
        {
            id: '4',
            type: 'hospital',
            name: 'Clínica Ricardo Palma',
            lat: -12.0897,
            lng: -77.0282,
            address: 'Av. Javier Prado Este 1066, San Isidro',
            phone: '01-224-2224',
            hours: '24 horas'
        },
        {
            id: '5',
            type: 'policia',
            name: 'Comisaría Miraflores',
            lat: -12.1198,
            lng: -77.0289,
            address: 'Av. Reducto 1401, Miraflores',
            phone: '01-445-5786',
            hours: '24 horas'
        },
        {
            id: '6',
            type: 'hospital',
            name: 'Hospital Rebagliati',
            lat: -12.0858,
            lng: -77.0504,
            address: 'Av. Rebagliati 490, Jesús María',
            phone: '01-265-4901',
            hours: '24 horas'
        }
    ];
}

function getMarkerColor(type) {
    const colors = {
        policia: '#3b82f6',
        serenazgo: '#22c55e',
        bomberos: '#ef4444',
        hospital: '#a855f7'
    };
    return colors[type] || '#6b7280';
}

function centerOnUserLocation(mapId) {
    const mapElement = document.getElementById(mapId);
    if (!mapElement || !mapElement._leaflet_map) {
        console.error('Map not found');
        return;
    }

    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const { latitude, longitude } = position.coords;
                const map = mapElement._leaflet_map;

                map.setView([latitude, longitude], 15);

                map.eachLayer((layer) => {
                    if (layer.options && layer.options.isUserMarker) {
                        map.removeLayer(layer);
                    }
                });

                const userIcon = L.divIcon({
                    className: 'user-marker',
                    html: `<div style="background-color: #4f46e5; width: 20px; height: 20px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 5px rgba(0,0,0,0.3);"></div>`,
                    iconSize: [20, 20]
                });

                L.marker([latitude, longitude], { icon: userIcon, isUserMarker: true })
                    .bindPopup('Tu ubicación actual')
                    .addTo(map);
            },
            (error) => {
                console.error('Error getting location:', error);
                alert('No se pudo obtener tu ubicación: ' + error.message);
            }
        );
    } else {
        alert('La geolocalización no está soportada en este navegador');
    }
}

function initReportMap(elementId, initialLat = -12.0464, initialLng = -77.0428) {
    const mapElement = document.getElementById(elementId);
    if (!mapElement) return null;

    const map = L.map(elementId).setView([initialLat, initialLng], 13);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors',
        maxZoom: 19
    }).addTo(map);

    let marker = null;
    map.on('click', function(e) {
        const { lat, lng } = e.latlng;

        if (marker) {
            map.removeLayer(marker);
        }
        marker = L.marker([lat, lng]).addTo(map);

        if (window.onMapLocationSelected) {
            window.onMapLocationSelected(lat, lng);
        }
    });

    return map;
}

function loadReportsOnMap(map) {
    map.eachLayer((layer) => {
        if (layer instanceof L.Marker && layer.options.isReportMarker) {
            map.removeLayer(layer);
        }
    });

    const reports = storage ? storage.getAllReports() : [];

    reports.forEach(report => {
        if (report.location && report.location.lat && report.location.lng) {
            const color = getSeverityColor(report.severity);
            const icon = L.divIcon({
                className: 'report-marker',
                html: `<div style="background-color: ${color}; width: 25px; height: 25px; border-radius: 50%; border: 2px solid white; box-shadow: 0 2px 5px rgba(0,0,0,0.3);"></div>`,
                iconSize: [25, 25]
            });

            const popupContent = `
                <div style="min-width: 200px;">
                    <strong style="font-size: 14px; display: block; margin-bottom: 8px;">${report.incidentType}</strong>
                    <p style="margin: 4px 0; font-size: 12px;">${report.description || 'Sin descripción'}</p>
                    <p style="margin: 4px 0; font-size: 12px;"><strong>Estado:</strong> ${getStatusLabel(report.status)}</p>
                    <p style="margin: 4px 0; font-size: 11px; color: #666;">${formatTimeAgo(report.createdAt)}</p>
                </div>
            `;

            L.marker([report.location.lat, report.location.lng], {
                icon,
                isReportMarker: true
            })
                .bindPopup(popupContent)
                .addTo(map);
        }
    });
}

function getSeverityColor(severity) {
    const colors = {
        high: '#ef4444',
        medium: '#f59e0b',
        low: '#3b82f6'
    };
    return colors[severity] || '#6b7280';
}

function getStatusLabel(status) {
    const labels = {
        pending: 'Pendiente',
        confirmed: 'Confirmado',
        resolved: 'Resuelto',
        rejected: 'Rechazado'
    };
    return labels[status] || status;
}

function formatTimeAgo(dateString) {
    if (!dateString) return 'Hace un momento';

    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);

    if (diffMins < 1) return 'Hace un momento';
    if (diffMins < 60) return `Hace ${diffMins} min`;

    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `Hace ${diffHours}h`;

    const diffDays = Math.floor(diffHours / 24);
    if (diffDays === 1) return 'Ayer';
    if (diffDays < 7) return `Hace ${diffDays} días`;

    return date.toLocaleDateString('es-PE');
}

if (typeof window !== 'undefined') {
    window.mapInstances = {};
}
